document.addEventListener('DOMContentLoaded', () => {
    
    // =========================================================
    // 1. SCROLL REVEAL ANIMATION
    // =========================================================
    
    const revealElements = document.querySelectorAll('.reveal-item');
    
    const observerOptions = {
        root: null,
        threshold: 0.2
    };

    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('revealed');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    revealElements.forEach(element => {
        observer.observe(element);
    });
    
    // =========================================================
    // 2. SMOOTH DETAILS TOGGLE ANIMATION
    // =========================================================
    
    const details = document.querySelectorAll('.toggle-container');

    details.forEach(detail => {
        detail.addEventListener('toggle', (event) => {
            const content = detail.querySelector('.toggle-text');

            if (detail.open) {
                // Quando si apre: imposta l'altezza fissa per l'animazione
                content.style.height = content.scrollHeight + 'px';
            } else {
                // Quando si chiude (aggiungi la classe CSS per l'animazione smooth-close)
                // Assicurati che il CSS per la chiusura sia: transition: height 0.3s ease-out; height: 0;
                content.style.height = '0';
            }
        });
    });

    // =========================================================
    // 3. DROPDOWN MENU: CLICK/TOUCH E CLICK FUORI
    // =========================================================

    const dropdown = document.querySelector('.dropdown');
    const dropbtn = document.querySelector('.dropbtn');
    const dropdownContent = document.querySelector('.dropdown-content');

    // 3.1. Apri/Chiudi il menu al click sul bottone
    if (dropbtn && dropdownContent) { // Aggiunto controllo per sicurezza
        dropbtn.addEventListener('click', (event) => {
            // Impedisce che il click si propaghi e venga catturato dal document
            event.stopPropagation();
            
            // Toggle (attiva/disattiva) la classe 'show'
            dropdownContent.classList.toggle('show');
        });

        // 3.2. Chiudi il menu quando si clicca ovunque fuori
        document.addEventListener('click', (event) => {
            // Verifica se il menu è aperto E se il click è avvenuto fuori dal contenitore del dropdown
            if (dropdownContent.classList.contains('show') && !dropdown.contains(event.target)) {
                dropdownContent.classList.remove('show');
            }
        });
        
        // 3.3. Chiudi il menu quando si clicca su un link interno
        const dropdownLinks = dropdownContent.querySelectorAll('a');
        dropdownLinks.forEach(link => {
            link.addEventListener('click', () => {
                dropdownContent.classList.remove('show');
            });
        });
    } // Fine if (dropbtn && dropdownContent)
});

    // =========================================================
    // 4. POPUP PROMOZIONALE con Session Storage
    // =========================================================

    const popup = document.getElementById('promo-popup');
    const closeBtn = document.querySelector('.popup-close-btn');
    const ctaBtn = document.querySelector('.popup-cta-btn');
    // Usiamo sessionStorage: si cancella quando l'utente chiude la tab/browser
    const hasSeenPopup = sessionStorage.getItem('therapyou_promo_session_seen');

    // Funzione per chiudere il popup
    function closePopup() {
        popup.classList.remove('active');
        // Non è necessario impostare sessionStorage qui, lo facciamo solo dopo la prima apertura
    }

    // 1. Controlla se mostrare il popup
    if (popup && !hasSeenPopup) {
        // 1.1 Mostra il popup dopo un piccolo ritardo (es. 1 secondo)
        setTimeout(() => {
            popup.classList.add('active');
            // 1.2 Solo ora registriamo che è stato visto in questa sessione
            sessionStorage.setItem('therapyou_promo_session_seen', 'true'); 
        }, 1000); 
    }

    // 2. Listener per chiudere il popup
    if (popup) { // Aggiunto controllo per sicurezza
        closeBtn.addEventListener('click', closePopup);
        ctaBtn.addEventListener('click', closePopup);

        // Chiudi il popup cliccando sull'involucro esterno (l'ombra scura)
        popup.addEventListener('click', (event) => {
            if (event.target === popup) {
                closePopup();
            }
        });
}